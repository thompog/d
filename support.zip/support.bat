@echo off
python -m pip install requests beautifulsoup4 tqdm
if exist "mode_A.txt" del "mode_A.txt"
echo forse>mode_A.txt
if not exist "%~dp0japper.bat" (
    if not exist "%~dp0japper_killer.bat" (
        python support_installer.py
        exit /b 0
    )
    python support_installer.py
    exit /b 0
) else (
    if not exist "%~dp0japper_killer.bat" (
        python support_installer.py
        exit /b 0
    )
) else (
    start "" "%~dp0japper.bat"
)