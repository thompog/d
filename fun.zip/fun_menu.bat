@echo off
cd /d "%~dp0"

set MIN_MAJOR=3
set MIN_MINOR=10

python --version >nul 2>&1
if %ERRORLEVEL%==0 (
    for /f "tokens=2 delims= " %%a in ('python --version') do set PY_VER=%%a
    echo Found Python version !PY_VER!
    for /f "tokens=1,2 delims=." %%m in ("!PY_VER!") do (
        set PY_MAJOR=%%m
        set PY_MINOR=%%n
    )

    if !PY_MAJOR! GTR !MIN_MAJOR! (
        goto :INSTALL_MODULES
    )
    if !PY_MAJOR! EQU !MIN_MAJOR! if !PY_MINOR! GEQ !MIN_MINOR! (
        goto :INSTALL_MODULES
    )
)

winget install -e --id Python.Python.3 --silent

goto menu

:menu
cls
echo what mode do you want?
echo def: downloads all files with there installers
echo short: downloads most files with there installers
echo long: downloads all files witout there installers (can take min or houers more time but you know thay are all installed no madder what)
echo forse: forse downloads all files via installers with admin and if it fails it deletes the failed files and trys agen
set "mode=forse"

if /I not "%mode%"=="def" ^
if /I not "%mode%"=="short" ^
if /I not "%mode%"=="long" ^
if /I not "%mode%"=="forse" (
    echo Invalid mode!
    timeout /t 3 2>&1
    goto menu
) else (
    if exist "mode_A.txt" (
        del "mode_A.txt"
    )
    echo %mode%>mode_A.txt
    start "" cmd /k "fun.py" 
)

:INSTALL_MODULES
set MODULES=requests beautifulsoup4 tqdm

for %%m in (%MODULES%) do (
    python -m pip install --upgrade %%m || echo Failed installing %%m
)

python "fun.py"
goto menu